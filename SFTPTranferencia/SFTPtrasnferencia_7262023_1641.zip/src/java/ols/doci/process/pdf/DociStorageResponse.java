/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ols.doci.process.pdf;

/**
 *
 * @author ols.kevin.osorio
 */
public class DociStorageResponse
{
    public String s3;
    public String correlativointerno;
    public String templatepath;
    public String fechaemision;
    public String companyid;
    public String sello;
    public String diskgroup;
    public String filefullpath;
    public String numerocontrol;
    public String codigogeneracion;
    public String statustibo;
    public String statusmh;
    public int revnum;
    public int itemtypenum;
    public int itemnum;
    public String nit;
    public int id;
    public String shorttoken;
    public String codgeneracioninvalidado;
    public String sellorecibidoinvalidado;

    public String getS3()
    {
        return s3;
    }

    public void setS3(String s3)
    {
        this.s3 = s3;
    }

    public String getCorrelativointerno()
    {
        return correlativointerno;
    }

    public void setCorrelativointerno(String correlativointerno)
    {
        this.correlativointerno = correlativointerno;
    }

    public String getTemplatepath()
    {
        return templatepath;
    }

    public void setTemplatepath(String templatepath)
    {
        this.templatepath = templatepath;
    }

    public String getFechaemision()
    {
        return fechaemision;
    }

    public void setFechaemision(String fechaemision)
    {
        this.fechaemision = fechaemision;
    }

    public String getCompanyid()
    {
        return companyid;
    }

    public void setCompanyid(String companyid)
    {
        this.companyid = companyid;
    }

    public String getSello()
    {
        return sello;
    }

    public void setSello(String sello)
    {
        this.sello = sello;
    }

    public String getDiskgroup()
    {
        return diskgroup;
    }

    public void setDiskgroup(String diskgroup)
    {
        this.diskgroup = diskgroup;
    }

    public String getFilefullpath()
    {
        return filefullpath;
    }

    public void setFilefullpath(String filefullpath)
    {
        this.filefullpath = filefullpath;
    }

    public String getNumerocontrol()
    {
        return numerocontrol;
    }

    public void setNumerocontrol(String numerocontrol)
    {
        this.numerocontrol = numerocontrol;
    }

    public String getCodigogeneracion()
    {
        return codigogeneracion;
    }

    public void setCodigogeneracion(String codigogeneracion)
    {
        this.codigogeneracion = codigogeneracion;
    }

    public String getStatustibo()
    {
        return statustibo;
    }

    public void setStatustibo(String statustibo)
    {
        this.statustibo = statustibo;
    }

    public String getStatusmh()
    {
        return statusmh;
    }

    public void setStatusmh(String statusmh)
    {
        this.statusmh = statusmh;
    }

    public int getRevnum()
    {
        return revnum;
    }

    public void setRevnum(int revnum)
    {
        this.revnum = revnum;
    }

    public int getItemtypenum()
    {
        return itemtypenum;
    }

    public void setItemtypenum(int itemtypenum)
    {
        this.itemtypenum = itemtypenum;
    }

    public int getItemnum()
    {
        return itemnum;
    }

    public void setItemnum(int itemnum)
    {
        this.itemnum = itemnum;
    }

    public String getNit()
    {
        return nit;
    }

    public void setNit(String nit)
    {
        this.nit = nit;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getShorttoken()
    {
        return shorttoken;
    }

    public void setShorttoken(String shorttoken)
    {
        this.shorttoken = shorttoken;
    }

    public String getCodgeneracioninvalidado()
    {
        return codgeneracioninvalidado;
    }

    public void setCodgeneracioninvalidado(String codgeneracioninvalidado)
    {
        this.codgeneracioninvalidado = codgeneracioninvalidado;
    }

    public String getSellorecibidoinvalidado()
    {
        return sellorecibidoinvalidado;
    }

    public void setSellorecibidoinvalidado(String sellorecibidoinvalidado)
    {
        this.sellorecibidoinvalidado = sellorecibidoinvalidado;
    }

}
