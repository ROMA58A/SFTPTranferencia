package com.ols.doci.job;

/**
 * @author Luis Brayan
 */
public enum CronIntervalUnits
{
    SECONDS,
    MINUTES,
    HOURS;
}
